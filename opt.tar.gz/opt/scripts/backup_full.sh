#!/bin/bash

print_usage() {
    echo "USO: $0 input_folder output_folder"
    echo "Crea una copia de seguridad de la carpeta de entrada y la almacena en la de salida"
    echo "Ejemplo: $0 /path/to/input /path/to/output"
}

# Muestra el ejemplo de ayuda si haces ./full_backup.sh -h o --help
if [ "$#" -eq 1 ] && { [ "$1" == "--help" ] || [ "$1" == "-h" ]; }; then
    print_usage
    exit 0
fi

#No cumplio con la condición de arriba, chequeo si tengo input_folder y output_folder para hacer el backup
if [ "$#" -ne 2 ]; then
    echo "Error: Faltan argumentos"
    print_usage
    exit 1
fi

input_folder="$1"
output_folder="$2"


#Chequeo si existen las carpetas desde/hasta donde se tiene que hacer el backup
if [ ! -d "$input_folder" ]; then
    echo "Error: No existe la carpeta de entrada"
    exit 1
fi

if [ ! -d "$output_folder" ]; then
    echo "Error: No existe la carpeta de salida"
    exit 1
fi

#date por default te devuelve la fecha con el locale que tengas configurada la maquina
#ej: Wed Jul 17 18:29:54 -03 2024 en mi caso q lo tengo en ingles
current_date=$(date +"%Y%m%d")

backup_file="$output_folder/$(basename "$input_folder")_bkp_$current_date.tar.gz"

#basename me devuelve la última parte de un path, ej:
#cyphersproject@Zephyrus ~ → basename /home/ignacio
#ignacio
tar -czf "$backup_file" -C "$(dirname "$input_folder")" "$(basename "$input_folder")"

echo "Backup de $input_folder guardado en $backup_file"
